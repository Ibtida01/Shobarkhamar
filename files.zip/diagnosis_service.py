from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from fastapi import HTTPException, status, UploadFile, Request
from uuid import UUID
from typing import List, Optional
import os
from datetime import datetime
from app.models.diagnosis import Diagnosis, DiagnosisSymptom, DiagnosisImage, DiagnosisStatus
from app.schemas.diagnosis import DiagnosisCreate, DiagnosisUpdate
from app.core.config import settings


class DiagnosisService:
    """Service for diagnosis-related operations"""

    # ── helpers ────────────────────────────────────────────────

    @staticmethod
    async def _fetch_full(db: AsyncSession, diagnosis_id: UUID) -> Diagnosis:
        result = await db.execute(
            select(Diagnosis)
            .options(
                selectinload(Diagnosis.images),
                selectinload(Diagnosis.symptoms),
                selectinload(Diagnosis.final_disease),
            )
            .where(Diagnosis.diagnosis_id == diagnosis_id)
        )
        diagnosis = result.scalar_one_or_none()
        if not diagnosis:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Diagnosis not found")
        return diagnosis

    # ── public API ─────────────────────────────────────────────

    @staticmethod
    async def get_by_id(db: AsyncSession, diagnosis_id: UUID) -> Diagnosis:
        return await DiagnosisService._fetch_full(db, diagnosis_id)

    @staticmethod
    async def get_by_user(
        db: AsyncSession, user_id: UUID, skip: int = 0, limit: int = 100
    ) -> List[Diagnosis]:
        result = await db.execute(
            select(Diagnosis)
            .options(selectinload(Diagnosis.images), selectinload(Diagnosis.final_disease))
            .where(Diagnosis.user_id == user_id)
            .offset(skip)
            .limit(limit)
            .order_by(Diagnosis.created_at.desc())
        )
        return result.scalars().all()

    @staticmethod
    async def create(
        db: AsyncSession, user_id: UUID, diagnosis_data: DiagnosisCreate
    ) -> Diagnosis:
        diagnosis = Diagnosis(
            user_id=user_id,
            farm_id=diagnosis_data.farm_id,
            unit_id=diagnosis_data.unit_id,
            target_species=diagnosis_data.target_species,
            symptoms_text=diagnosis_data.symptoms_text,
            status=DiagnosisStatus.PENDING,
        )
        db.add(diagnosis)
        await db.flush()

        if diagnosis_data.symptom_ids:
            for symptom_id in diagnosis_data.symptom_ids:
                db.add(DiagnosisSymptom(
                    diagnosis_id=diagnosis.diagnosis_id,
                    symptom_id=symptom_id
                ))

        await db.commit()
        return await DiagnosisService._fetch_full(db, diagnosis.diagnosis_id)

    @staticmethod
    async def update(
        db: AsyncSession, diagnosis_id: UUID, diagnosis_data: DiagnosisUpdate
    ) -> Diagnosis:
        diagnosis = await DiagnosisService._fetch_full(db, diagnosis_id)

        for field, value in diagnosis_data.dict(exclude_unset=True, exclude={"symptom_ids"}).items():
            setattr(diagnosis, field, value)

        if diagnosis_data.symptom_ids is not None:
            for symptom_id in diagnosis_data.symptom_ids:
                db.add(DiagnosisSymptom(diagnosis_id=diagnosis_id, symptom_id=symptom_id))

        diagnosis.updated_at = datetime.utcnow()
        await db.commit()
        return await DiagnosisService._fetch_full(db, diagnosis_id)

    @staticmethod
    async def delete(db: AsyncSession, diagnosis_id: UUID) -> None:
        diagnosis = await DiagnosisService._fetch_full(db, diagnosis_id)
        await db.delete(diagnosis)
        await db.commit()

    @staticmethod
    async def upload_image(
        db: AsyncSession,
        diagnosis_id: UUID,
        file: UploadFile,
        ai_detector=None,          # pass app.state.ai_detector from the router
    ) -> DiagnosisImage:
        """
        1. Save the uploaded image to disk
        2. Create DiagnosisImage record
        3. If AI detector is available, run inference and update the diagnosis
        """
        # Verify diagnosis exists
        diagnosis = await DiagnosisService._fetch_full(db, diagnosis_id)

        # Save file
        os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
        ext = os.path.splitext(file.filename or "image.jpg")[1] or ".jpg"
        filename = f"{diagnosis_id}_{datetime.utcnow().timestamp()}{ext}"
        file_path = os.path.join(settings.UPLOAD_DIR, filename)

        with open(file_path, "wb") as buf:
            buf.write(await file.read())

        # Create image record
        diagnosis_image = DiagnosisImage(
            diagnosis_id=diagnosis_id,
            image_url=f"/uploads/{filename}",
        )
        db.add(diagnosis_image)

        # ── AI inference ──────────────────────────────────────
        if ai_detector is not None:
            try:
                diagnosis.status = DiagnosisStatus.PROCESSING
                await db.flush()

                result = ai_detector.predict(file_path)
                primary = result["primary_prediction"]

                diagnosis.ai_confidence = primary["confidence"]
                diagnosis.ai_disease_code = primary["disease_code"]
                diagnosis.status = DiagnosisStatus.COMPLETED
                print(
                    f"✓ AI result for {diagnosis_id}: "
                    f"{primary['disease_name']} ({primary['confidence_percent']}%)"
                )
            except Exception as e:
                diagnosis.status = DiagnosisStatus.FAILED
                print(f"⚠️  AI inference failed for {diagnosis_id}: {e}")
        else:
            # No model — mark as completed without AI result
            diagnosis.status = DiagnosisStatus.COMPLETED

        diagnosis.updated_at = datetime.utcnow()
        await db.commit()
        await db.refresh(diagnosis_image)
        return diagnosis_image
